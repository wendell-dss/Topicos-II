
#ifndef INT_H
#define INT_H

int array_maior(int v[], int tam);
char to_Uppper(char v);
int maior(int a, int b);

#endif