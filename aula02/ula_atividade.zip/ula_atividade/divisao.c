float divisao(int a, int b)
{
    return a / b;
}