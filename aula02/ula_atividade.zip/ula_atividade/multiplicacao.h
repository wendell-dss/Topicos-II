int mult(int a, int b);
